import React  from "react";

export default function Account() {
    return(
        <div className="container">
            <div className="row">
                <div className="col-2">
                    <img src="images/l3.jpg" width="100%" />
                </div>

                <div className="col-2">
                    <div className="form-container">
                        <div className="form-btn">
                            <span onClick="login()">Login</span>
                            <span onClick="register()">Register</span>
                            <hr id="Indicator" />
                        </div>

                        <form id="LoginForm">
                            <input type="text"  placeholder="Username"/>
                            <br/>
                            <input type="password"  placeholder="Password"/>
                            <br/>
                            <button type="Submit" className="btn">Login</button>
                            <a href="">Forgot Password</a>
                        </form>

                        <form id="RegForm">
                            <input type="text" placeholder="Username"/>
                            <br/>
                            <input type="email" placeholder="Email"/>
                            <br/>
                            <input type="password" placeholder="Password"/>
                            
                            <button type="Submit" className="btn">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}