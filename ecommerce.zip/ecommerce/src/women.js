import React from "react";

export default function Women(){
    return(
        <div>
            <h2 class="title">Women Clothes</h2>
            <div class="row">
                <div class="col-4">
                    <img src="images/w1.jpg"/>
                    <h4>Blush Floral Mesh Top</h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹13,000.00 - ₹19,099.00</p>
                </div>
                <div class="col-4">
                    <img src="images/w2.jpg"/>
                    <h4>Square Neck Top </h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹2000.00</p>
                </div>
                <div class="col-4">
                    <img src="images/w3.jpg"/>
                    <h4>Blush Floral Mesh Top</h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
                <div class="col-4">
                    <img src="images/w4.jpg"/>
                    <h4>Square Neck Top </h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹12,999.00 </p>
                </div>
                <div class="col-4">
                    <a href="productdetail.html"><img src="images/w5.jpg"/></a>
                    <h4>Mustard Work It Up Top</h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹299.00 - ₹1,099.00</p>
                </div>
                <div class="col-4">
                    <img src="images/w6.jpg"/>
                    <h4>Blush Floral Mesh Top</h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹400 - ₹1,099.00</p>
                </div>
                <div class="col-4">
                    <img src="images/w7.jpg"/>
                    <h4>Mustard Work It Up Top</h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹500.00 - ₹1,099.00</p>
                </div>
                <div class="col-4">
                    <img src="images/w8.jpg"/>
                    <h4>Square Neck Top </h4>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="far fa-star"></i>
                    </div>
                    <p>Price:	₹299.00 - ₹1,099.00</p>
                </div>
            </div>
        </div>   
    )
}