import React from "react";

export default function Brands() {
  return (
    <div className="footer">
      <div className="container">
        <div className="row">
          <div className="footer-col-1">
            <h3>Download our app</h3>
            <p>Download App for android and ios mobile phones.</p>
            <div className="app-logo">
              <img src={"/images/play-store.png"} alt="myimage" />
              <img src={"/images/app-store.png"} alt="myimage" />
            </div>
          </div>
          <div className="footer-col-2">
            <h3>E shopify</h3>
            <p>Brand product availaible here</p>
          </div>
          <div className="footer-col-3">
            <h3>Useful links</h3>
            <ul>
              <li>Coupens</li>
              <li>Discount</li>
              <li>Blog Post</li>
              <li>Return Policy</li>
            </ul>
          </div>
          <div className="footer-col-4">
            <h3>Follow us</h3>
            <ul>
              <li>Twitter</li>
              <li>Facebook</li>
              <li>Instagram</li>
              <li>Linkdin</li>
            </ul>
          </div>
          <div className="footer-col-5">
            <h3>Contact us</h3>
            <ul>
              <li>+444 677889</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
