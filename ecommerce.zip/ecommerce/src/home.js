import Featuredcategories from "./featuredcategories";
import Featuredproducts from "./featuredproducts";
import Latestproducts from "./latestproducts";
import Womencloths from "./womencloths";
import Offer from "./offer";
import Testinmonials from "./testimonials";
import Brands from "./brands";
import Header from "./header";


export default function Home() {
  return (
    <div>  
      <Header />  
      <Featuredcategories />
      <Featuredproducts />
      <Latestproducts />
      <Womencloths />
      <Offer />
      <Testinmonials />
      <Brands />
    </div>
  );
}
