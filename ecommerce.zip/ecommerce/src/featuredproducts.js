import React from "react";

export default function Featuredproducts() {
  return (
    <div className="">
       
      <h2 className="title">Featured Products</h2>
      <div className="row">
          
        <div className="col-4">
          <img src="images/product-3.jpg" />
          <h4>Men's Cotton T-Shirt</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹299.00 - ₹1,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/product-2.jpg" />
          <h4>Sport Shoes for men</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹500.00</p>
        </div>
        <div className="col-4">
          <img src="images/product-4.jpg" />
          <h4>Cotton T-Shirt</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹400.00 - ₹1,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/product-5.jpg" />
          <h4>Style Sport Shoes for ment</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹299.00 - ₹1,099.00</p>
        </div>
      </div>
    </div>
  );
}
