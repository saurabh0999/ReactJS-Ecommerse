import React from "react";

export default function Latestproducts() {
  return(
    <div className="">
     <h2 className="title">Latest Products</h2>
     <div className="row">
      <div className="col-4">
          <img src="images/arr_img1.jpg"/>
          <h4>LCD TV</h4>
          <div className="rating">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="far fa-star"></i>
              <i className="far fa-star"></i>
          </div>
              <p>Price:	₹13,000.00 - ₹19,099.00</p>
          </div>
          <div className="col-4">
              <img src="images/arr_img2.jpg" />
              <h4>Video Game</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹2000.00</p>
          </div>
          <div className="col-4">
              <img src="images/arr_img3.jpg" />
              <h4>Sport Shoes</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹400.00 - ₹1,099.00</p>
          </div>
          <div className="col-4">
              <img src="images/arr_img4.jpg" />
              <h4>Smart Phones</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹12,999.00 </p>
          </div>
          <div className="col-4">
              <img src="images/product-5.jpg"/>
              <h4>Style Sport Shoes for men</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹299.00 - ₹1,099.00</p>
          </div>
          <div className="col-4">
              <img src="images/product-6.jpg"/>
              <h4>Men's Cotton T-shirt</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹400 - ₹1,099.00</p>
          </div>
          <div className="col-4">
              <img src="images/product-8.jpg"/>
              <h4>Smart watches</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹500.00 - ₹1,099.00</p>
          </div>
          <div className="col-4">
              <img src="images/product-2.jpg"/>
              <h4>Sport Shoes for men</h4>
              <div className="rating">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
              </div>
              <p>Price:	₹299.00 - ₹1,099.00</p>
          </div>
      </div>
    </div>
  );
}
