import React  from "react";

export default function Shoppingcart() {
    return(
        <div class="small-contain cart-page">
            <table>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="images/w5.jpg" width="60px"/>
                            <div>
                                <p>Floral Mesh Top</p>
                                <small>Price: ₹1300.00 </small>
                                <br/>
                                <a href="">Remove</a>

                            </div>

                        </div>
                    </td>
                    <td><input type="number" value="1"/></td>
                    <td>₹1300.00 </td>
                </tr>
                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="images/w1.jpg" width="60px"/>
                            <div>
                                <p>Top For Women</p>
                                <small>Price:  ₹1999.00</small>
                                <br/>
                                <a href="">Remove</a>

                            </div>

                        </div>
                    </td>
                    <td><input type="number" value="1"/></td>
                    <td>₹1999.00 </td>
                </tr>
                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="images/buy-1.jpg" width="60px"/>
                            <div>
                                <p>Red Printed T-shirt</p>
                                <small>Price: ₹1300.00 </small>
                                <br/>
                                <a href="">Remove</a>

                            </div>

                        </div>
                    </td>
                    <td><input type="number" value="1"/></td>
                    <td>₹1300.00 </td>
                </tr>
                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="images/watch3.jpg" width="60px"/>
                            <div>
                                <p>Smart Watch</p>
                                <small>Price: ₹1900.00 </small>
                                <br/>
                                <a href="">Remove</a>

                            </div>

                        </div>
                    </td>
                    <td><input type="number" value="1"/></td>
                    <td>₹1900.00 </td>
                </tr>
            </table>
            <div class="total-price">
                <table>
                    <tr>
                        <td>Subtotal</td>
                        <td>₹1300.00</td>
                    </tr>
                    <tr>
                        <td>Tax</td>
                        <td>₹80.00</td>
                    </tr>
                    <tr>
                        <td>Total</td>
                        <td>₹2300.00</td>
                    </tr>
                </table>
            </div>
        </div>
    )
}