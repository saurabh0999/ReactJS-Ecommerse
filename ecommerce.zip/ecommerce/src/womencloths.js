import React from "react";

export default function Offer() {
  return (
    <div>
      <h2 className="title">Women Clothes</h2>
      <div className="row">
        <div className="col-4">
          <img src="images/w1.jpg" />
          <h4>Blush Floral Mesh Top</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹13,000.00 - ₹19,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/w2.jpg" />
          <h4>Square Neck Top </h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹2000.00</p>
        </div>
        <div className="col-4">
          <img src="images/w3.jpg" />
          <h4>Blush Floral Mesh Top</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹400.00 - ₹1,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/w4.jpg" />
          <h4>Square Neck Top </h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹12,999.00 </p>
        </div>
        <div className="col-4">
          <img src="images/w5.jpg" />
          <h4>Mustard Work It Up Top</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹299.00 - ₹1,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/w6.jpg" />
          <h4>Blush Floral Mesh Top</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹400 - ₹1,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/w7.jpg" />
          <h4>Mustard Work It Up Top</h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹500.00 - ₹1,099.00</p>
        </div>
        <div className="col-4">
          <img src="images/w8.jpg" />
          <h4>Square Neck Top </h4>
          <div className="rating">
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="fas fa-star"></i>
            <i className="far fa-star"></i>
          </div>
          <p>Price: ₹299.00 - ₹1,099.00</p>
        </div>
      </div>
    </div>
  );
}
