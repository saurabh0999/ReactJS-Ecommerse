import React  from "react";

export default function Kids() {
    return(
        <div>
            <h2 className="title">Kids Clothes</h2>
            <div className="row">
                <div className="col-4">
                    <img src="images/k1.jpg"/>
                    <h4>Girl Top</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹13,000.00 - ₹19,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/k2.jpg"/>
                    <h4>Boy T-shirt</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹2000.00</p>
                </div>
                <div className="col-4">
                    <img src="images/k3.jpg"/>
                    <h4>Dress For Boy</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/k4.jpg"/>
                    <h4> Girl Dress </h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹12,999.00 </p>
                </div>

            </div>
        </div>
    )
}