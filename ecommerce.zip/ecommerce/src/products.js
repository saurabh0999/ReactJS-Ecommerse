import React  from "react";

export default function Products() {
    return(
        <div className="small-contain">
            <div className="row row-2">
            <h2>All Products</h2>
            <select>
                <option>Short by Price</option>
                <option>Short by Size</option>
                <option>Short by Popularity</option>
            </select>
            </div>
            <div className="row">
            <div className="col-4">
                    <img src="images/product-3.jpg"/>
                    <h4>Men's Cotton T-Shirt</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹299.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/w1.jpg"/>
                    <h4>Blush Floral Mesh Top</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹13,000.00 - ₹19,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/w2.jpg"/>
                    <h4>Square Neck Top </h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹2000.00</p>
                </div>
                <div className="col-4">
                    <img src="images/product-4.jpg"/>
                    <h4>Cotton T-Shirt</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
            </div>
            
            <div className="row">
                <div className="col-4">
                    <img src="images/w3.jpg"/>
                    <h4>Blush Floral Mesh Top</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/w4.jpg"/>
                    <h4>Square Neck Top </h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹12,999.00 </p>
                </div>
                <div className="col-4">
                    <img src="images/w5.jpg"/>
                    <h4>Mustard Work It Up Top</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹299.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/w6.jpg"/>
                    <h4>Blush Floral Mesh Top</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400 - ₹1,099.00</p>
                </div>
            </div>
            <h2 className="title">Smart Watches</h2>
            <div className="row">
                <div className="col-4">
                    <img src="images/watch3.jpg"/>
                    <h4>Watch For men</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/watch1.jpg"/>
                    <h4>Watch For men</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/watch3.jpg"/>
                    <h4>Watch For men</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
                <div className="col-4">
                    <img src="images/watch4.jpg"/>
                    <h4>Watch For men</h4>
                    <div className="rating">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="far fa-star"></i>
                        <i className="far fa-star"></i>
                    </div>
                    <p>Price:	₹400.00 - ₹1,099.00</p>
                </div>
            </div>
            <div className="page-btn">
                <span>1</span>
                <span>2</span>
                <span>3</span>
                <span>4</span>
                <span>&#8594</span>
            </div>
        </div>
    )
}