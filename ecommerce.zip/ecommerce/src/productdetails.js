import React  from "react";

export default function Productdetails() {
    return(
        <div>
            <div className="small-contain single-product">
                <div className="row">
                    <div className="col-2">
                        <img src="images/w5.jpg" width="100%" id="ProductImg"/>
                        <div className="small-img-row">
                            <div className="small-img-col">
                                <img src="images/w51.jpg" width="100%" className="small-img"/>
                            </div>
                            <div className="small-img-col">
                                <img src="images/w52.jpg" width="100%" className="small-img"/>
                            </div>
                            <div className="small-img-col">
                                <img src="images/w53.jpg" width="100%" className="small-img"/>
                            </div>
                            <div className="small-img-col">
                                <img src="images/w5.jpg" width="100%" className="small-img" />
                            </div>
                        </div>
                    </div>
                <div className="col-2" >
                        <p>Home/Top For women</p>
                        <h2>Blush Floral Mesh Top</h2>
                        <h4>Price:	₹1300.00 - ₹1999.00</h4>
                        <select>
                            <option>Select Size</option>
                            <option>XXL</option>
                            <option>XL</option>
                            <option>L</option>
                            <option>M</option>
                        </select>
                        <input type="number" value="1"/>
                        <a href="shoppingcart.html" className="btn">Add to cart</a>
                        <h3>Detail Featured <i className="fa fa-indent"></i></h3>
                        <p>Pink round neck mesh top with embroidered floral detail and short flutter sleeves
                            Pink round neck mesh top with embroidered floral detail and short flutter sleeves
                            Made of 100% Nylon Mesh
                            Length: Regular
                            Regular fit
                            Round Neck
                            Return Period: 15 Days</p>
                    </div>
                </div>
            </div>
            
            <div className="small-contain">
                <div className="row row-2">
                    <h2>Related Products</h2>
                    <p>View More</p>
                </div>
            </div>

            <div className="small-contain">
                <div className="row">
                    <div className="col-4">
                        <img src="images/w5.jpg"/>
                        <h4>Blush Floral Mesh Top</h4>
                        <div className="rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                            <i className="far fa-star"></i>
                        </div>
                        <p>Price:	₹1300.00 - ₹1999.00</p>
                    </div>
                    <div className="col-4">
                        <img src="images/w2.jpg"/>
                        <h4>Square Neck Top </h4>
                        <div className="rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                            <i className="far fa-star"></i>
                        </div>
                        <p>Price:	₹2000.00</p>
                    </div>
                    <div className="col-4">
                        <img src="images/w3.jpg"/>
                        <h4>Blush Floral Mesh Top</h4>
                        <div className="rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                            <i className="far fa-star"></i>
                        </div>
                        <p>Price:	₹400.00 - ₹1,099.00</p>
                    </div>
                    <div className="col-4">
                        <img src="images/w4.jpg"/>
                        <h4>Square Neck Top </h4>
                        <div className="rating">
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="fas fa-star"></i>
                            <i className="far fa-star"></i>
                        </div>
                        <p>Price:	₹12,999.00 </p>
                    </div>             
                </div>  
            </div>
        </div>
    )
}