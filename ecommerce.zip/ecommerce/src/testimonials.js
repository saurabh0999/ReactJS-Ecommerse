import React from "react";

export default function Testinmonials() {
  return (
    <div className="testimonial">
      <div className="small-contain">
        <div className="row">
          <div className="col-3">
            <i className="fa fa-quote-left"></i>
            <p>
              Despite some negative publicity around Honest Company, we've found
              it to produce quality products we like and trust.
            </p>
            <div className="rating">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="far fa-star"></i>
              <i className="far fa-star"></i>
            </div>
            <img src="images/user-1.png" />
            <h3>sama ketra</h3>
          </div>
          <div className="col-3">
            <i className="fa fa-quote-left"></i>
            <p>
              Despite some negative publicity around Honest Company, we've found
              it to produce quality products we like and trust.
            </p>
            <div className="rating">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="far fa-star"></i>
              <i className="far fa-star"></i>
            </div>
            <img src="images/user-2.png" />
            <h3>depsh jha</h3>
          </div>
          <div className="col-3">
            <i className="fa fa-quote-left"></i>
            <p>
              Despite some negative publicity around Honest Company, we've found
              it to produce quality products we like and trust.
            </p>
            <div className="rating">
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="fas fa-star"></i>
              <i className="far fa-star"></i>
              <i className="far fa-star"></i>
            </div>
            <img src="images/user-3.png" />
            <h3>sanen parhe</h3>
          </div>
        </div>
      </div>
    </div>
  );
}
