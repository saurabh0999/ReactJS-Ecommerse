import React from "react";
import { Link } from 'react-router-dom';

export default function Nav() {
    function menutoggle(){

    }
    return (
        <div className="">
        <div className="container">
            <div className="navbar">
            <div className="logo">
                <h1>E Shopify</h1>
            </div>
            <div className="search-box">
                <input
                className="search-txt"
                type="text"
                name=""
                placeholder="Type to serach"
                />
                <Link className="search-btn" href="#">
                <i className="fa fa-search" aria-hidden="true"></i>
                </Link>
            </div>
            <nav>
                <ul id="MenuItems">
                <li>
                    <Link to="/home">Home</Link>
                </li>
                <li>
                    <Link to="/products">Product</Link>
                </li>
                <li>
                    <Link to="/women">Womens</Link>
                </li>
                
                <li>
                    <Link to="kids">Kids</Link>
                </li>
                
                <li>
                    <Link to="/">Account</Link>
                </li>
                </ul>
            </nav>
            <Link to="/shoppingcart"><img src="images/cart.png" alt="myimage" width="30px" height="30px" /></Link>
            <img
                src={"images/menu.png"}
                alt="myimage"
                className="menu-icon"
                onclick="menutoggle()"
            />
            </div>
        </div>
        </div>
    );
}
